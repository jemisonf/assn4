#include "pokemon.h"

class Psychic: public Pokemon {
	public:
	     Psychic(int);
	     Event* clone();
};
